//
//  SecondViewController.swift
//  RaspSenseHat
//
//  Created by Patrick Pinard on 2017-08-28.
//  Copyright © 2017 Patrick Pinard. All rights reserved.
//

import UIKit
import Charts

class GraphViewController: UIViewController {

    
    @IBOutlet weak var tempChartView: LineChartView!
    var temps : [Double] = [] //list of temperature to show in the graph
    
    @IBOutlet weak var humidityChartView: LineChartView!
    var humidity : [Double] = [] //list of humidity to show in the graph
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getDataTemps()
        getDatahumidity()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func refreshData(_ sender: Any) {
        getDataTemps()
        getDatahumidity()
    }


    // call rest class to get Data
    // update chart whit temps data
    func getDataTemps(){
        temps = []
        let restGetData = RestGetData()
        restGetData.getempsData() { data in
            for column in 0...data.count-1 {
                
                self.temps.append(round(100*data[column])/100)
                print(self.temps[column])
            }
            print("temps[]")
            print(self.temps)
            self.updateTempGraph()
        }
    }
    
    // update chartview
    func updateTempGraph(){
        var lineChartEntry  = [ChartDataEntry]() //this is the Array that will eventually be displayed on the graph.
        
        //here is the for loop
        for i in 0..<temps.count {
            
            let value = ChartDataEntry(x: Double(i), y: temps[i]) // here we set the X and Y status in a data chart entry
            
            lineChartEntry.append(value) // here we add it to the data set
        }
        
        let line1 = LineChartDataSet(values: lineChartEntry, label: "Temp") //Here we convert lineChartEntry to a LineChartDataSet
        
        line1.colors = [NSUIColor.green] //Sets the colour to blue
        line1.setCircleColor(NSUIColor.green)
        line1.circleHoleColor = NSUIColor.green
        line1.circleRadius = 1
        let gradientColors = [UIColor.green.cgColor, UIColor.green.cgColor] as CFArray
        let colorLocations: [CGFloat] = [1.0,0.0]
        guard let gradient = CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColors, locations: colorLocations) else { print("error gratient"); return}
        line1.fill = Fill.fillWithLinearGradient(gradient, angle: 90.0)
        line1.drawFilledEnabled = true
        
        let data = LineChartData() //This is the object that will be added to the chart
        data.addDataSet(line1) //Adds the line to the dataSet
        data.setDrawValues(false)
        data.setValueTextColor(NSUIColor.green)
        
        tempChartView.data = data //finally - it adds the chart data to the chart and causes an update
        
        
        
        // Set axis graph
        
        tempChartView.xAxis.drawLabelsEnabled = false
        tempChartView.xAxis.drawGridLinesEnabled = false
        
        tempChartView.rightAxis.enabled = false

        tempChartView.leftAxis.axisMinimum = 0
        tempChartView.leftAxis.axisMaximum = 30
        tempChartView.leftAxis.drawLabelsEnabled = true
        tempChartView.leftAxis.labelTextColor = UIColor.green
        tempChartView.leftAxis.drawGridLinesEnabled = false
        
        tempChartView.borderColor = UIColor.green
        tempChartView.borderLineWidth = 1
        
        tempChartView.legend.enabled = false
        tempChartView.chartDescription?.text = ""
        tempChartView.animate(xAxisDuration: 0.5, yAxisDuration: 2.0, easingOption: .easeInCubic)
        
    }

    // call rest class to get Data
    // update chart whit himidity data
    func getDatahumidity(){
        humidity = []
        let restGetData = RestGetData()
        restGetData.getHumidityData() { data in
            for column in 0...data.count-1 {
                
                self.humidity.append(round(100*data[column])/100)
                print(self.humidity[column])
            }
            print("temps[]")
            print(self.humidity)
            self.updatehumidityGraph()
        }
    }
    
    // update chartview
    func updatehumidityGraph(){
        var lineChartEntry  = [ChartDataEntry]() //this is the Array that will eventually be displayed on the graph.
        
        //here is the for loop
        for i in 0..<humidity.count {
            
            let value = ChartDataEntry(x: Double(i), y: humidity[i]) // here we set the X and Y status in a data chart entry
            
            lineChartEntry.append(value) // here we add it to the data set
        }
        
        let line1 = LineChartDataSet(values: lineChartEntry, label: "humidity") //Here we convert lineChartEntry to a LineChartDataSet
        
        line1.colors = [NSUIColor.blue] //Sets the colour to blue
        line1.setCircleColor(NSUIColor.blue)
        line1.circleHoleColor = NSUIColor.blue
        line1.circleRadius = 1.5
        let gradientColors = [UIColor.blue.cgColor, UIColor.blue.cgColor] as CFArray
        let colorLocations: [CGFloat] = [1.0,0.0]
        guard let gradient = CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColors, locations: colorLocations) else { print("error gratient"); return}
        line1.fill = Fill.fillWithLinearGradient(gradient, angle: 90.0)
        line1.drawFilledEnabled = true
        
        let data = LineChartData() //This is the object that will be added to the chart
        data.addDataSet(line1) //Adds the line to the dataSet
        data.setDrawValues(false)
        data.setValueTextColor(NSUIColor.blue)
        
        humidityChartView.data = data //finally - it adds the chart data to the chart and causes an update
        
        
        
        // Set axis graph
        
        humidityChartView.xAxis.drawLabelsEnabled = false
        humidityChartView.xAxis.drawGridLinesEnabled = false
        
        humidityChartView.rightAxis.enabled = false
        
        humidityChartView.leftAxis.axisMinimum = 0
        humidityChartView.leftAxis.axisMaximum = 100
        humidityChartView.leftAxis.drawLabelsEnabled = true
        humidityChartView.leftAxis.labelTextColor = UIColor.blue
        humidityChartView.leftAxis.drawGridLinesEnabled = false
        
        humidityChartView.borderColor = UIColor.blue
        humidityChartView.borderLineWidth = 1
        
        humidityChartView.legend.enabled = false
        humidityChartView.chartDescription?.text = ""
        
        humidityChartView.animate(xAxisDuration: 3.0, yAxisDuration: 2.0, easingOption: .easeInSine)
        
    }

}

