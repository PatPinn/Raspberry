//
//  RaspViewController.swift
//  RaspSenseHat
//
//  Created by Patrick Pinard on 2017-08-29.
//  Copyright © 2017 Patrick Pinard. All rights reserved.
//

import UIKit

class RaspViewController: UIViewController {
    
    @IBOutlet weak var CPU: UILabel!
    @IBOutlet weak var mem: UILabel!
    @IBOutlet weak var CPUTemp: UILabel!
    @IBOutlet weak var IP: UILabel!
    @IBOutlet weak var WIFI: UILabel!
    @IBOutlet weak var dateTime: UILabel!
    @IBOutlet weak var refreshButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshButton.layer.cornerRadius = 5
        refreshButton.layer.borderWidth = 1
        refreshButton.layer.borderColor = UIColor.white.cgColor
        refreshView()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        refreshView()
    }
    
    

    @IBAction func refreshData(_ sender: Any) {
        refreshView()
    }
    
    // call getRaspData from class GetEnvInfo
    // refresh label in the view
    func refreshView(){
        let restGetData = RestGetData()
        //Call rest API
        restGetData.getRaspData(){ info in
            
            //refresh view
            DispatchQueue.main.async(execute: {
                self.dateTime.text = info[0]
                self.CPU.text = info[2]
                self.CPUTemp.text = info[1]
                self.mem.text = info[3]
                self.IP.text = info[4]
                self.WIFI.text = info[5]
            })
            
        }
    }
    
}
