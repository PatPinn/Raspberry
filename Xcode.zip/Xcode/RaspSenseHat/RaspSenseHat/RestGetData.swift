//
//  RestGetData.swift
//  RaspSenseHat
//
//  Created by Patrick Pinard on 2017-08-28.
//  Copyright © 2017 Patrick Pinard. All rights reserved.
//

import Foundation

class RestGetData  {
    
    /*
     * function to get Raspberry PI Info Data
     * call Node Red Rest API
     * https://your-nodeRed-instnace/raspData?
     * extract the JSON Data
     * send back [String] with the Data
     */
    func getRaspData(completionHandler: @escaping ([String]) -> Void) {
        
        var info: [String] = ["","","","","",""]

        // Info on rest API call un the node red
        let defaults = UserDefaults.standard
        var nodeRedURL: String = "https://nodered-patraspberry.mybluemix.net/"
        if let urlSaved = defaults.string(forKey: "URL"){
            nodeRedURL = urlSaved
        }
        let todoEndpoint: String = nodeRedURL+"raspData?"
        guard let url = URL(string: todoEndpoint) else {
            print("Error: cannot create URL")
            return
        }
        
        //call rest API
        let urlRequest = URLRequest(url: url)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /raspData")
                print(error!)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            // parse the result as JSON
            do {
                guard let jsonData = try JSONSerialization.jsonObject(with: responseData, options: [])
                    as? [String: Any] else {
                        print("error trying to convert data to JSON")
                        return
                }
                // now we have the todo
                // let's just print it to prove we can access it
                print("The jsonTemp is: " + jsonData.description)
                
                guard let dataJSON = jsonData["data"] as? [String: String]else {
                    print("Could not get data from JSON")
                    return
                }
                
                guard let newtime = dataJSON["time"] else {
                    print("Could not get time from JSON")
                    return
                }
                guard let newCPUtemperature = dataJSON["CPUtemp"] else {
                    print("Could not get CPUtemp from JSON")
                    return
                }
                guard let newCPU = dataJSON["CPU"] else {
                    print("Could not get CPU from JSON")
                    return
                }
                guard let newMem = dataJSON["memory"] else {
                    print("Could not get millibar from JSON")
                    return
                }
                guard let newIP = dataJSON["IP"] else {
                    print("Could not get IP from JSON")
                    return
                }
                guard let newWIFI = dataJSON["WIFI"] else {
                    print("Could not get WIFI from JSON")
                    return
                }
                
                
                //set data to view
                info[0] = newtime
                info[1] = newCPUtemperature + " c"
                info[2] = newCPU + "%"
                info[3] = newMem + "%"
                info[4] = newIP
                info[5] = newWIFI
                
                // wait completion before return info[]
                completionHandler(info)
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
        }
        task.resume()
        
    }
    
    /*
     * function to get Raspberry PI Sense Hat Env Data
     * call Node Red Rest API
     * https://your-nodeRed-instnace/envData?
     * extract the JSON Data
     * send back [String] with the Data
     */
    func getEnvData(completionHandler: @escaping ([String]) -> Void) {
        
        var info: [String] = ["","","",""]
        
        // Info on rest API call un the node red
        let defaults = UserDefaults.standard
        var nodeRedURL: String = "https://nodered-patraspberry.mybluemix.net/"
        if let urlSaved = defaults.string(forKey: "URL"){
            nodeRedURL = urlSaved
        }
        let todoEndpoint: String = nodeRedURL+"envData?"
        guard let url = URL(string: todoEndpoint) else {
            print("Error: cannot create URL")
            return
        }
        
        //call rest API
        let urlRequest = URLRequest(url: url)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /envData")
                print(error!)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            // parse the result as JSON
            do {
                guard let jsonData = try JSONSerialization.jsonObject(with: responseData, options: [])
                    as? [String: Any] else {
                        print("error trying to convert data to JSON")
                        return
                }
                // now we have the todo
                // let's just print it to prove we can access it
                print("The jsonTemp is: " + jsonData.description)
                
                guard let dataJSON = jsonData["data"] as? [String: String]else {
                    print("Could not get data from JSON")
                    return
                }
                
                guard let newtime = dataJSON["time"] else {
                    print("Could not get time from JSON")
                    return
                }
                guard let newtemperature = dataJSON["temperature"] else {
                    print("Could not get temp from JSON")
                    return
                }
                guard let newHumidity = dataJSON["humidity"] else {
                    print("Could not get humidity from JSON")
                    return
                }
                guard let newMillibar = dataJSON["pressure"] else {
                    print("Could not get millibar from JSON")
                    return
                }
                
                
                //set data to view
                info[0] = newtime
                info[1] = newtemperature + " c"
                info[2] = newHumidity + "%"
                info[3] = newMillibar + " millbar"
                
                // wait completion before return info[]
                completionHandler(info)
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
        }
        task.resume()
    }

    /*
     * function to get Raspberry PI Sense Hat Env Tempretures
     * call Node Red Rest API
     * https://your-nodeRed-instnace/tempsData?
     * extract the JSON Data
     * send back [Double] with the temperatures
     */
    func getempsData(completionHandler: @escaping ([Double]) -> Void) {
        
        
        // Info on rest API call un the node red
        let defaults = UserDefaults.standard
        var nodeRedURL: String = "https://nodered-patraspberry.mybluemix.net/"
        if let urlSaved = defaults.string(forKey: "URL"){
            nodeRedURL = urlSaved
        }
        let todoEndpoint: String = nodeRedURL+"tempsData?"
        guard let url = URL(string: todoEndpoint) else {
            print("Error: cannot create URL")
            return
        }
        
        //call rest API
        let urlRequest = URLRequest(url: url)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /tempsData")
                print(error!)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            // parse the result as JSON
            do {
                guard let jsonData = try JSONSerialization.jsonObject(with: responseData, options: [])
                    as? [String: Any] else {
                        print("error trying to convert data to JSON")
                        return
                }
                // now we have the todo
                // let's just print it to prove we can access it
                print("The jsonTemps is: " + jsonData.description)
                
                guard let dataJSON = jsonData["data"] as? [String: [Double]] else {
                    print("Could not get data from JSON")
                    return
                }
                
                guard let temps = dataJSON["temps"] else {
                    print("Could not get temps from JSON")
                    return
                }
                
                
                
                // wait completion before return info[]
                completionHandler(temps)
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
        }
        task.resume()
        
    }

    /*
     * function to get Raspberry PI Sense Hat Env humidity
     * call Node Red Rest API
     * https://your-nodeRed-instnace/humidityData?
     * extract the JSON Data
     * send back [Double] with the himidity
     */
    func getHumidityData(completionHandler: @escaping ([Double]) -> Void) {
        
        
        // Info on rest API call un the node red
        let defaults = UserDefaults.standard
        var nodeRedURL: String = "https://nodered-patraspberry.mybluemix.net/"
        if let urlSaved = defaults.string(forKey: "URL"){
            nodeRedURL = urlSaved
        }
        let todoEndpoint: String = nodeRedURL+"humidityData?"
        guard let url = URL(string: todoEndpoint) else {
            print("Error: cannot create URL")
            return
        }
        
        //call rest API
        let urlRequest = URLRequest(url: url)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /humidityData")
                print(error!)
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            // parse the result as JSON
            do {
                guard let jsonData = try JSONSerialization.jsonObject(with: responseData, options: [])
                    as? [String: Any] else {
                        print("error trying to convert data to JSON")
                        return
                }
                // now we have the todo
                // let's just print it to prove we can access it
                print("The jsonTemps is: " + jsonData.description)
                
                guard let dataJSON = jsonData["data"] as? [String: [Double]] else {
                    print("Could not get data from JSON")
                    return
                }
                
                guard let humidity = dataJSON["humidity"] else {
                    print("Could not get humidity from JSON")
                    return
                }
                
                
                
                // wait completion before return info[]
                completionHandler(humidity)
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
        }
        task.resume()
        
    }
}
