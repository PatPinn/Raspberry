//
//  SetupViewController.swift
//  RaspSenseHat
//
//  Created by Patrick Pinard on 2017-08-29.
//  Copyright © 2017 Patrick Pinard. All rights reserved.
//

import UIKit

class SetupViewController: UIViewController {
    
    
    @IBOutlet weak var url: UITextField!
    @IBOutlet weak var saveButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = UserDefaults.standard
        if let urlSaved = defaults.string(forKey: "URL"){
            url.text = urlSaved
        }
        saveButton.layer.cornerRadius = 5
        saveButton.layer.borderWidth = 1
        saveButton.layer.borderColor = UIColor.white.cgColor
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func save(_ sender: Any) {
        let defaults = UserDefaults.standard
        defaults.set(url.text, forKey: "URL")
    }
   
}
